# GoRaider - Speed where it matters

Rough speed (Ran on my own hardware and internet): 

  <img src="speed.gif">

A nuke bot made in golang for discord. I've decided to release the private version, (minus some stuff) as I don't like maintaining this anymore.


There is some hacky fixes for errors I've encountered. No, I will not fix any errors that you have with this bot.

I would appreciate credit, but I know how people are so there will be a few who claim it as their own.


Made by:

  [Not-Cyrus - entire golang part](https://github.com/Not-Cyrus)
  
  [lxi1337/lxi1400 - member scraper (.py file)](https://github.com/lxi1400)
